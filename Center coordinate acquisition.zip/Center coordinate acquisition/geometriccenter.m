
function coor = geometriccenter(mask)
 
[label,num] = bwlabel(mask);


coor = zeros(num,2);
for n = 1:num
    [x,y] = find(label==n);
    coor(n,:) = [mean(x),mean(y)];
end

end