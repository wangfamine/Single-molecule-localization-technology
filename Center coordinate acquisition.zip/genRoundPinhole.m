function [pinhole]=genRoundPinhole(pinholeD)
centerX=round(pinholeD/2);
centerY=round(pinholeD/2);
% mask=zeros(pinholeSize);
% for i=1:pinholeSize
%     for j=1:pinholeSize
%         if((i-centerX)^2+(j-centerY)^2<=radius^2)
%             mask(i,j)=1;
%         end
%     end
% end

xx=1:pinholeD;
yy=1:pinholeD;
[xxx,yyy]=meshgrid(xx,yy);
radius=pinholeD/2;
mask=(xxx-centerX).^2+(yyy-centerY).^2<=radius^2;
pinhole=ones(pinholeD).*mask;