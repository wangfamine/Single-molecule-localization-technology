

clear all;
close all;
lamda=0.514e-6;%
nada=0.514e-6;
pixel_CCD=6.5e-6;
pixel_SLM=9.2e-6;
k=2*pi/lamda;%
NA=1.4;
M=100;
f=150e-3;
px=f*NA/sqrt(M^2-NA^2);
py=f*NA/sqrt(M^2-NA^2);    %%%
numAx=round(2*f*NA/M/pixel_SLM)+1;
numAy=round(2*f*NA/M/pixel_SLM)+1;
vx=linspace(-px,px,numAy);
vy=linspace(-py,py,numAy);
[x,y]=meshgrid(vx,vy);
pupilRadius_x=px;
pupilRadius_y=py;
R=pupilRadius_x;
rou=sqrt(x.^2+y.^2);
phi=zeros(numAy,numAy);

xxli=x/max(max(abs(x)));
yyli=y/max(max(abs(y)));

Dize=ceil(f*lamda/pixel_CCD/pixel_SLM);

for i=1:length(x)
   for j=1:length(x)
    if y(i,j)>=0&&x(i,j)^2+y(i,j)^2<=pupilRadius_x^2
       phi(i,j)=acos(x(i,j)/rou(i,j)); 
    else if y(i,j)<0&&x(i,j)^2+y(i,j)^2<=pupilRadius_y^2
       phi(i,j)=2*pi-acos(x(i,j)/rou(i,j));
        else
       phi(i,j)=0;
    end
   end
   end
end


for i=1:length(x)
   for j=1:length(x)
 
   p0(i,j)= rou(i,j).*exp(1i.* phi(i,j)); 
   
   p1(i,j)= rou(i,j).*exp(1i.* phi(i,j))- rou(229,100).*exp(1i.* phi(229,100));   
   p1fu(i,j)= rou(i,j).*exp(1i.* phi(i,j))+ rou(229,100).*exp(1i.* phi(229,100));   
   
   p2(i,j)= rou(i,j).*exp(1i.* phi(i,j))- rou(229,70).*exp(1i.* phi(229,70));   
   p2fu(i,j)= rou(i,j).*exp(1i.* phi(i,j))+ rou(229,70).*exp(1i.* phi(229,70));   
   
   p3(i,j)= rou(i,j).*exp(1i.* phi(i,j))- rou(229,40).*exp(1i.* phi(229,40));   
   p3fu(i,j)= rou(i,j).*exp(1i.* phi(i,j))+ rou(229,40).*exp(1i.* phi(229,40));
   
   p4(i,j)= rou(i,j).*exp(1i.* phi(i,j))- rou(229,10).*exp(1i.* phi(229,10));   
   p4fu(i,j)= rou(i,j).*exp(1i.* phi(i,j))+ rou(229,10).*exp(1i.* phi(229,10));

   end
end

for i=1:length(x)
   for j=1:length(x)
       p(i,j)=p1(i,j).*p0(i,j).*p1fu(i,j).*p2(i,j).*p2fu(i,j).*p3(i,j).*p3fu(i,j).*p4(i,j).*p4fu(i,j); 
   end
end


p2=angle(p);
ppp1=mod(p2,2*pi);

figure(1);imshow(ppp1,[]);


 PP4=ppp1;
 A=genRoundPinhole(numAy);
 tian=floor((Dize-numAx)/2);
  xiangwei=padarray(ppp1,[tian,tian]); 
  AA=padarray(A,[tian,tian]);
  
 z=[-1e-6:0.1e-6:1e-6];
[m,n]=size(z);
pu=0.5*Dize*pixel_SLM;
pv=0.5*Dize*pixel_SLM;
vu=linspace(-pu,pu,Dize);
vv=linspace(-pv,pv,Dize);
[u,v]=meshgrid(vu,vv);

xiangwei1=xiangwei;
 figure(2),imshow(xiangwei1,[]);
 title('depth');

maxmaxiii1=zeros(n);
  for i1=1:1:n
    efp=AA.*exp(1i.*xiangwei1).*exp(-1i*(2*pi/(2*nada*f))*((0.81*(z(i1))*M^2)/f).*(u.^2+v.^2));
    f1=(fft2(efp));
    I1(:,:,i1)=abs(f1).^2;
    III1(:,:,i1)= fftshift(I1(:,:,i1));
    maxmaxiii3(i1)=max(max(I1(:,:,i1)));
  end

  figure(6),plot(maxmaxiii3);
   for i=1:n
   Labels=-1+0.1*i;

  figure(14),imshow(III1(595:695,595:695, i),[]);
     title(['Axial depth=' num2str(Labels)]);
  pause(0.1);
   end
   


  mask_linshi=III1(:,:,11)>0.8*max(max(III1(:,:,11)));
  coor_zhong=geometriccenter(mask_linshi);
 distance2=sqrt((coor_zhong(1,1)-coor_zhong(2,1))^2+(coor_zhong(1,2)-coor_zhong(2,2))^2);
   
 
 figure(6);imshow(fftshift( I1(:,:,1)),[]);

 coor_zhong1=zeros(2,2,n);

   for i=1:1:21
    mask_linshi(:,:,i)=III1(:,:,i)>0.98*max(max(III1(:,:,i)));
    coor_zhong1(:,:,i)=geometriccenter(mask_linshi(:,:,i));
    distance(i)=sqrt((coor_zhong1(1,1,i)-coor_zhong1(2,1,i))^2+(coor_zhong1(1,2,i)-coor_zhong1(2,2,i))^2);
   end
   distance4P=distance*6.5/100;
   figure(7),plot(distance4P);
  
    figure(5);imshow(III1(:,:,12),[]);
    coor_zhong1(:,:,12)=[637 646;655 646];  


 
 